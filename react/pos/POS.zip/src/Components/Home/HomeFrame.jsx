import React from 'react'

function HomeFrame() {
  return (
    <div>
      <h1>Home Page</h1>
      <h2>Details About My POS</h2>
    </div>
  )
}

export default HomeFrame
