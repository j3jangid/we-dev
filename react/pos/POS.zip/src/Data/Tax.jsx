const tax = [0, 5, 12, 18, 28];

export default tax;