const Company = {
    logo: require("../Data/IMG/deity_itself_logo_crop.jpg"),
    name: "deity itSelf",
    address: "Shop no. 12 Triveni Nagar Delhi Road",
    city: "Jaipur",
    state: "Rajasthan",
    pincode: "302012",
    country: "India",
    mobileNo: 123567890,
    emailId: "deity_itself@gmail.com",
    gstNo: "08ABCDE9999F1Z8",
}

export default Company;