const termAndCondition = [
    "Payment will due in 7 days from invoice date.",
    "Products damaged during transit will not be covered under the warranty.",
    "10% restocking charges are applicable on all non-defective replacements.",
    "Late interest @ 2% of the outstanding balance per day.",
    "Cheque bounce charge 900Rs"
];

export default termAndCondition;