const category = ["abc", "xyz", "sdk"];

export default category;