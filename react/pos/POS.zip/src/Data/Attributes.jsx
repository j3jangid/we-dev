const attribute = {
        color: ["red", "white", "blue", "black"],
        size: ["s", "m", "l", "xl", "xxl"],
        brand: ["apple", "nokia", "samsung", "moto"]
    };

    export default attribute;