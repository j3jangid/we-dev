const units = ["pcs", "kgs", "pak", "box", "mtr"];

export default units;