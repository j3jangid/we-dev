const Data = [
    {
        title: "HTML",
        topics: ["Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html"],
    },
    {
        title: "Css",
        topics: ["Introduction of Css", "Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html"],
    },
    {
        title: "Bootstrap",
        topics: ["Introduction of Bootstrap", "Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html"],
    },
    {
        title: "js",
        topics: ["Introduction of js", "Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html"],
    },
    {
        title: "React",
        topics: ["Introduction of React", "Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html"],
    },
    {
        title: "Node",
        topics: ["Introduction of Node", "Introduction of Html", "Introduction of Html", "Introduction of Html", "Introduction of Html"],
    },
]
export default Data